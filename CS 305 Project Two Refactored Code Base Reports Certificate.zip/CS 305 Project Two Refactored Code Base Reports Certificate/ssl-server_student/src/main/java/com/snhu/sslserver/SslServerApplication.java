//Braxton Morrow
//SNHU
//CS 305

package com.snhu.sslserver;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication
public class SslServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SslServerApplication.class, args);
	}

}
@RestController
class ServerController{
	//creates a message digest object
	private MessageDigest md;
	private ServerController() throws NoSuchAlgorithmException {
		//setter
		this.md = MessageDigest.getInstance("SHA-256");
	}
	
    //Add hash function to return the checksum value for the data string that should contain your name.
    @RequestMapping("/hash")
    public String myHash(){
    	String data = "Hello Braxton Morrow!";
    	byte[] inputBytes = data.getBytes();
    	byte [] hashBytes = md.digest(inputBytes);
    	String hex = ServerController.bytesToHex(hashBytes);
    	return "<p>data: " + data + "</p><p>name of cypher algorithm used: SHA-256, value: " + hex + "</p>"; 
    }
    
    //BytestoHex function
    private static String bytesToHex(byte[] hash) {
        StringBuilder hexString = new StringBuilder(2 * hash.length);
        for (int i = 0; i < hash.length; i++) {
            String hex = Integer.toHexString(0xff & hash[i]);
            if(hex.length() == 1) {
                hexString.append('0');
            }
            hexString.append(hex);
        }
        return hexString.toString();
    }
}
